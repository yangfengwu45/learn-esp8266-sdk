/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "ets_sys.h"
#include "osapi.h"
#include "user_tcpclient.h"
#include "user_interface.h"

#include "user_devicefind.h"
#include "user_webserver.h"

#if ESP_PLATFORM
#include "user_esp_platform.h"
#endif

#include "driver/uart.h" //����uart.h


#include  "espconn.h"
#include  "mem.h"


struct espconn TcpServer;//TCP�������õĽṹ��


struct espconn *TCPSendDate = NULL;//��������ʹ��



extern u8  Usart0ReadBuff[Usart0ReadLen];//�������ݵ�����
extern u32 Usart0ReadCnt;//����1���յ������ݸ���
extern u32 Usart0IdelCnt;
extern u32 Usart0ReadCntCopy;//����1���յ������ݸ�������


uint32 priv_param_start_sec;

/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 ICACHE_FLASH_ATTR
user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            priv_param_start_sec = 0x3C;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            priv_param_start_sec = 0x7C;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
            rf_cal_sec = 512 - 5;
            priv_param_start_sec = 0x7C;
            break;
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            priv_param_start_sec = 0xFC;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
            rf_cal_sec = 1024 - 5;
            priv_param_start_sec = 0x7C;
            break;
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            priv_param_start_sec = 0xFC;
            break;

        case FLASH_SIZE_64M_MAP_1024_1024:
            rf_cal_sec = 2048 - 5;
            priv_param_start_sec = 0xFC;
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            rf_cal_sec = 4096 - 5;
            priv_param_start_sec = 0xFC;
            break;
        default:
            rf_cal_sec = 0;
            priv_param_start_sec = 0;
            break;
    }

    return rf_cal_sec;
}



void ICACHE_FLASH_ATTR
user_rf_pre_init(void)
{
}

//�������ݻص�
void   TcpServerRecv(void *arg, char *pusrdata, unsigned short length){
	TCPSendDate = arg;
	uart0_tx_buffer(pusrdata,length);//���ڴ�ӡ���յ�����
}

//�Ͽ�
void   TcpServerDisCon(void *arg){

}
//�쳣�Ͽ�
void   TcpServerReCon(void *arg, sint8 err){

}

//���������˼���
void   TcpServerListen(void *arg)
{
	TCPSendDate = arg;
    struct espconn *pesp_conn = arg;//���մ������� espconn ��Ϣ
    espconn_regist_recvcb(pesp_conn, TcpServerRecv);//���ý��ջص�
    espconn_regist_disconcb(pesp_conn, TcpServerDisCon);//���öϿ����ӻص�
    espconn_regist_reconcb(pesp_conn, TcpServerReCon);
}


/**
* @brief   Ӳ����ʱ���жϻص�����
* @param   None
* @param   None
* @param   None
* @param   None
* @retval  None
* @warning None
* @example
**/
void hw_test_timer_cb(void)
{
    if(Usart0ReadCnt!=0){//���ڽ��յ�����
    	Usart0IdelCnt++;//����ʱ���ۼ�
        if(Usart0IdelCnt>10){//�ۼӵ�����ֵ(10ms)
        	Usart0IdelCnt=0;
            Usart0ReadCntCopy = Usart0ReadCnt;//�������յ����ݸ���
            Usart0ReadCnt=0;
            /*��������
             * ���ݻ�������:Usart0ReadBuff
             * ���ݳ���:Usart0ReadCntCopy
             * */
            if(TCPSendDate!=NULL){
            	espconn_send(TCPSendDate,Usart0ReadBuff,Usart0ReadCntCopy);
            }
        }
    }
}


/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void ICACHE_FLASH_ATTR
user_init(void)
{
	uart_init_2(BIT_RATE_115200,BIT_RATE_115200);

	espconn_init();//��ʼ��
	TcpServer.type = ESPCONN_TCP;     //����TCP
	TcpServer.state = ESPCONN_NONE;   //һ��ʼ��״̬
	TcpServer.proto.tcp = (esp_tcp *)os_malloc(sizeof(esp_tcp));

	TcpServer.proto.tcp->local_port = 8080;//�����Ķ˿ں�
	espconn_regist_connectcb(&TcpServer, TcpServerListen);//ע���������
	espconn_accept(&TcpServer);//��������

    //��ʱ����ʼ��
    hw_timer_init(0,1);//1:ѭ��
    //���ö�ʱ���ص�����
    hw_timer_set_func(hw_test_timer_cb);//hw_test_timer_cb:Ӳ����ʱ���жϻص�����
    hw_timer_arm(1000);//1000:1000us��ʱ�����жϺ���

}

