/*
 * ESPRSSIF MIT License
 *
 * Copyright (c) 2015 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "esp_common.h"
#include "gpio.h"
#include "esp_timer.h"
#include "hw_timer.h"
#include "uart.h"


extern char Usart0ReadBuff[Usart0ReadLen];//�������ݻ���
extern u32  Usart0ReadCnt;//���ڽ��յ����ݸ���
extern u32  Usart0ReadCntCopy;//���ڿ������ڽ��յ����ݸ���
extern u32  Usart0IdleCnt;//����ʱ���ۼӱ���

int i;

/*���ڷ��ؼ̵�����״̬*/
u8 RelayOn[4]={0x55,0xaa,0x01,0x01};//�̵�������
u8 RelayOff[4]={0x55,0xaa,0x01,0x00};//�̵����Ͽ�
/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 user_rf_cal_sector_set(void)
{
    flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;

        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}


/**
* @brief   Ӳ����ʱ���жϻص�����
* @param   None
* @param   None
* @param   None
* @param   None
* @retval  None
* @warning None
* @example
**/
void hw_test_timer_cb(void)
{
	if(Usart0ReadCnt!=0){//���ڽ��յ�����
		Usart0IdleCnt++;//����ʱ���ۼ�
		if(Usart0IdleCnt>Usart0IdleTime){//�ۼӵ�����ֵ(10ms)
			Usart0IdleCnt=0;
			Usart0ReadCntCopy = Usart0ReadCnt;//�������յ����ݸ���
			Usart0ReadCnt=0;
			/*��������
			 * ���ݻ�������:Usart0ReadBuff
			 * ���ݳ���:Usart0ReadCntCopy
			 * */
			if(Usart0ReadBuff[0] == 0xaa && Usart0ReadBuff[1] == 0x55){
				if(Usart0ReadBuff[2] == 0x01){
					if(Usart0ReadBuff[3] == 0x01){
						GPIO_OUTPUT_SET(5, 1);//����GPIO5����ߵ�ƽ
						for(i=0;i<4;i++){
							uart_tx_one_char(UART0,RelayOn[i]);//��������ָ��
						}
					}
					else if(Usart0ReadBuff[3] == 0x00){
						GPIO_OUTPUT_SET(5, 0);//����GPIO5����͵�ƽ
						for(i=0;i<4;i++){
							uart_tx_one_char(UART0,RelayOff[i]);//���ضϿ�ָ��
						}
					}
				}
			}
		}
	}
}
/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void user_init(void)
{
	uart_init_new();

    printf("SDK version:%s\n", system_get_sdk_version());
	printf("Ai-Thinker Technology Co. Ltd.\r\n%s %s\r\n", __DATE__, __TIME__);

	//��ʱ����ʼ��
	hw_timer_init(1);//1:ѭ��
	//���ö�ʱ���ص�����
	hw_timer_set_func(hw_test_timer_cb);//hw_test_timer_cb:Ӳ����ʱ���жϻص�����
	hw_timer_arm(1000);//1000:1000us��ʱ�����жϺ���

	/*����GPIO5Ϊ��ͨ����*/
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO5_U , FUNC_GPIO5);
}

