var searchData=
[
  ['upgrade_5fstates_5fcheck_5fcallback',['upgrade_states_check_callback',['../group__Upgrade__APIs.html#ga2897893fe6b22f7cd3159e57370dee7d',1,'upgrade.h']]],
  ['user_5fie_5fmanufacturer_5frecv_5fcb_5ft',['user_ie_manufacturer_recv_cb_t',['../group__WiFi__User__IE__APIs.html#ga48a93836b1b5d84a69592b90613cf01f',1,'esp_wifi.h']]],
  ['user_5fspi_5fflash_5fread',['user_spi_flash_read',['../group__SPI__Driver__APIs.html#gacda8d0eb9ddb859ea21726108d825f17',1,'spi_flash.h']]]
];
