/*
 * smart_config.h
 *
 *  Created on: 2019��8��29��
 *      Author: yang
 */

#ifndef APP_INCLUDE_SMART_CONFIG_H_
#define APP_INCLUDE_SMART_CONFIG_H_

void smartconfig_task(void *pvParameters);

#endif /* APP_INCLUDE_SMART_CONFIG_H_ */
