/*
 * dht11.h
 *
 *  Created on: 2019��11��29��
 *      Author: yang
 */

#ifndef APP_INCLUDE_DHT11_H_
#define APP_INCLUDE_DHT11_H_

#ifndef _DHT11_C_
#define _DHT11_Ex_ extern
#else
#define _DHT11_Ex_
#endif

#ifndef LOW
#define LOW     0
#endif /* ifndef LOW */

#ifndef HIGH
#define HIGH    1
#endif /* ifndef HIGH */

#define DHTLIB_TIMEOUT (100)


_DHT11_Ex_ u8 DHT11Data[5];  // �洢��ʪ������

void StartDHT11();

#endif /* APP_INCLUDE_DHT11_H_ */
