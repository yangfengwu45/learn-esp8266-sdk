/*
 * ESPRSSIF MIT License
 *
 * Copyright (c) 2015 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "esp_common.h"
#include "gpio.h"

#include "uart.h"
#include "esp_timer.h"
#include "hw_timer.h"
#include "pwm.h"
#include  "espconn.h"
#include  "esp_wifi.h"
#include "lwip/api.h"
#include "crc.h"
#include "smart_config.h"

#include "ConfigMqtt.h"
#include "dht11.h"
#include "oled.h"

LOCAL os_timer_t public_timer;//定时器
u32 public_timer_cnt=0;//累加
u32 public_timer_state=0;//状态
u32 public_timer_out=0;//超时
u32 public_timer_cnt1=0;//累加


extern u8  Usart1ReadBuff[Usart1ReadLen];//接收数据的数组
extern u32 Usart1ReadCnt;//串口1接收到的数据个数
extern u32 Usart1ReadCntCopy;//串口1接收到的数据个数拷贝
extern u8  Usart1ReadFlage;//串口1接收到一条完整数据


#define  SSID "Learn8266" //无线名称
#define	 PWD "11223344"	 //密码
struct softap_config soft_ap_Config;//AP模式配置


//缓存数据使用
char MainBuffer[500];//缓存数据,全局通用
u32  MainLen=0;      //全局通用变量
char *MainString;    //全局通用变量

//连接MQTT
char IP[4]={47,92,31,46};//IP地址/域名
int  Port =1883;//端口号
char MQTTid[30] = "123456";//设备ID  WIFI获取MAC,GPRS获取IMEI,如果想使用自定义ID 参见: FunctionParseGetID
char MQTTUserName[10] = "yang";//用户名
char MQTTPassWord[10] = "11223344";//密码
char MQTTkeepAlive = 5;//心跳包时间

//设置遗嘱
char MQTTWillFlage = 1;//1:使用遗嘱
//遗嘱发布的主题采用 char MQTTPublishTopic[30];里面的主题
char MQTTWillMessage[50] = "{\"data\":\"status\",\"status\":\"offline\"}";//遗嘱消息
char MQTTWillQos = 0;//消息等级
char MQTTWillRetained = 1;//是否需要服务器记录


char MQTTSubscribeTopic[30]="";//自定义订阅的主题,本程序使用user/WIFI的MAC

char MQTTPublishTopic[30]="";//存储MQTT发布的主题,本程序使用devic/WIFI的MAC
MQTTPublishTopicStruct MqttPublishTopicStruct = MQTTPublishTopicStruct_initializer;//定义一个用于发布消息用的结构体变量

//TCP客户端
struct espconn TcpClient;
esp_tcp esptcp;
char MqttState = 0;//连接MQTT的状态




//心跳包
u32  KeepAliveTimeOut = 0;   //判断心跳包返回超时
u32  KeepAliveTimeCnt = 0;   //到时间发送心跳包
char KeepAliveSendFlage = 0; //发送心跳包标志
char KeepAliveSendCount = 0; //发送心跳包次数
char SendKeepAliveFlage = 0; //需要发送心跳包数据



char RelayState = 0;//记录继电器状态
char SendRelayStateFlage = 0;//需要发送继电器数据


char SendTHFlage=0;//控制发送温湿度数据
int  SendTHCnt = 0;

/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 user_rf_cal_sector_set(void)
{
    flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;

        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}

//串口调用此函数就说明接收到了一条完整的数据,就可以去处理了
void UartReadCallback()//定义一个函数
{

}


static void wifi_event_monitor_handle_event_cb(System_Event_t *evt)
{
  switch (evt->event_id)
  {
	case EVENT_STAMODE_CONNECTED://连接上路由器
		dbg_printf("\n\tSTAMODE_CONNECTED\n");

		dbg_printf("\tConnected to SSID %s, Channel %d\n",
		  evt->event_info.connected.ssid,
		  evt->event_info.connected.channel);
	  break;

	case EVENT_STAMODE_DISCONNECTED://和路由器断开
		dbg_printf("\n\tSTAMODE_DISCONNECTED\n");

		dbg_printf("\tDisconnect from SSID %s, reason %d\n",
		  evt->event_info.disconnected.ssid,
		  evt->event_info.disconnected.reason);

	  break;

	case EVENT_STAMODE_AUTHMODE_CHANGE://这个是 啥..
		dbg_printf("\n\tSTAMODE_AUTHMODE_CHANGE\n");

		dbg_printf("\tAuthmode: %u -> %u\n",
		  evt->event_info.auth_change.old_mode,
		  evt->event_info.auth_change.new_mode);
	  break;

	case EVENT_STAMODE_GOT_IP://连接上路由器,并获取了IP
		dbg_printf("\n\tGOT_IP\n");

		dbg_printf("\tIP:" IPSTR ",Mask:" IPSTR ",GW:" IPSTR "\n",
		  IP2STR(&evt->event_info.got_ip.ip),
		  IP2STR(&evt->event_info.got_ip.mask),
		  IP2STR(&evt->event_info.got_ip.gw));
        if(public_timer_state == 0)//正常运行下连接的路由器
        {
        	espconn_connect(&TcpClient);//连接TCP服务器
        }
	  break;

	case EVENT_STAMODE_DHCP_TIMEOUT://连接上路由器,但是路由器给WIFI模块分配IP等信息超时了
		dbg_printf("\n\tSTAMODE_DHCP_TIMEOUT\n");
	  break;

	case EVENT_SOFTAPMODE_STACONNECTED://AP模式下,有设备连接WIFI模块的无线
		dbg_printf("\n\tSOFTAPMODE_STACONNECTED\n");

		dbg_printf("\tStation: " MACSTR "join, AID = %d\n",
		  MAC2STR(evt->event_info.sta_connected.mac),
		  evt->event_info.sta_connected.aid);
	  break;

	case EVENT_SOFTAPMODE_STADISCONNECTED://AP模式下,有设备断开和WIFI模块的无线连接
		dbg_printf("\n\tSOFTAPMODE_STADISCONNECTED\n");

		dbg_printf("\tstation: " MACSTR "leave, AID = %d\n",
		  MAC2STR(evt->event_info.sta_disconnected.mac),
		  evt->event_info.sta_disconnected.aid);
	  break;

	case EVENT_SOFTAPMODE_PROBEREQRECVED://这是啥??,,,信号强度改变了
		dbg_printf("\n\tSOFTAPMODE_PROBEREQRECVED\n");

		dbg_printf("Station PROBEREQ: " MACSTR " RSSI = %d\n",
		  MAC2STR(evt->event_info.ap_probereqrecved.mac),
		  evt->event_info.ap_probereqrecved.rssi);
	  break;

	default://其它错误
		dbg_printf("\n\tswitch/case default\n");
	  break;
  }
}





//网络接收到数据
void TcpClientRecv(void *arg, char *pdata, unsigned short len)
{
	memcpy(MqttAnalyzeStruct.buffRead,pdata,len);
	int Code=0;
	switch(MqttState)
	{
		case 1:
				Code = MqttConnectMqttAck();
				if(Code == 0)
				{
					MqttState = 2;
					dbg_printf("\nConnect MQTT Success\n");

					/*订阅一个主题*/
					MQTTString MQTTStringSubTopic[1] = MQTTString_initializer;//存储订阅的主题
					int MQTTStringSubTopicQos[1] = {0};//订阅主题的消息等级0

					#ifdef UserCustomConfig //使用自定义
						MQTTStringSubTopic[0].cstring = MQTTSubscribeTopic;//设置订阅的主题
					#else //user/Wi-Fi的MAC
						memset(MainBuffer,0,sizeof(MainBuffer));
						sprintf(MainBuffer,"%s%s","user/",&MQTTid[0]);//组合字符串

						MQTTStringSubTopic[0].cstring = MainBuffer;//设置订阅的主题
					#endif


					MainLen = MqttSubscribe(MQTTStringSubTopic,MQTTStringSubTopicQos,1,0,1);//打包订阅主题的协议,最终打包进 MqttSendData 数组
					if(MainLen>0)espconn_send(&TcpClient,MqttSendData,MainLen);//发送数据
						else dbg_printf("\nConnect MQTT Data Err\n");
				}
				else
				{
					espconn_disconnect(&TcpClient);
					espconn_delete(&TcpClient);
					espconn_connect(&TcpClient);//重新连接服务器
					MqttState = 0;
					dbg_printf("\nConnect MQTT Faild:%d\n",Code);
				}
			break;
		case 2:
			Code = MqttSubscribeAck();
			if(Code == 0){
				dbg_printf("\nSubscribe Success\n");
				MqttState = 3;

				MqttPublishTopicStruct.topicName.cstring = MQTTPublishTopic;//设置发布的主题
				MqttPublishTopicStruct.qos = 0;      //消息等级
				MqttPublishTopicStruct.retained = 1; //需要服务器保留消息
				MainLen= sprintf(MainBuffer,"{\"data\":\"status\",\"status\":\"online\"}");//组合发送的数据

				MainLen = MqttPublish(MqttPublishTopicStruct,MainBuffer,MainLen);//打包MQTT数据

				if(MainLen>0)espconn_send(&TcpClient,MqttSendData,MainLen);//发送数据
				else dbg_printf("\nSend Data Err\n");
			}
			else
			{
				dbg_printf("\nSubscribe Faild:%d\n",Code);
				espconn_disconnect(&TcpClient);
				espconn_delete(&TcpClient);
				espconn_connect(&TcpClient);//重新连接服务器
				MqttState = 0;
			}
			break;

	}

	if(MqttState == 3)
	{
		MqttAnalyzeStruct.Len = 0;//需要在这里清零,让函数从数组的开始地址读取
		if(MQTTPacket_read(MqttAnalyzeStruct.buff,MQTTAnalyzeBuffLen, transport_getdata) == PUBLISH)//接收到数据
		{
		  KeepAliveTimeOut=0;//如果持续通信,MQTT服务器会延迟发送心跳回复
			KeepAliveSendCount=0;

			MQTTDeserialize_publish(//提取MQTT接收的数据,数据提取到 MqttAnalyzeStruct 结构体变量里面的成员变量
				&MqttAnalyzeStruct.dup,
				&MqttAnalyzeStruct.qos,
				&MqttAnalyzeStruct.retained,
				&MqttAnalyzeStruct.packetid,
				&MqttAnalyzeStruct.topicName,
				&MqttAnalyzeStruct.payload,
				&MqttAnalyzeStruct.payloadlen,
				MqttAnalyzeStruct.buff,
				MQTTAnalyzeBuffLen
			);

			if(strstr((char*)MqttAnalyzeStruct.payload, "\"data\":\"switch\""))//询问开关
			{
				if(strstr((char*)MqttAnalyzeStruct.payload, "\"bit\":\"1\""))//第一路开关
				{
					if(strstr((char*)MqttAnalyzeStruct.payload, "\"status\":\"-1\""))//询问状态
					{
						SendRelayStateFlage = 1;
					}
					else if( strstr((char*)MqttAnalyzeStruct.payload, "\"status\":\"1\"") )//控制继电器吸合
					{
						GPIO_OUTPUT_SET(5, 1);
						SendRelayStateFlage = 1;
					}
					else if(strstr((char*)MqttAnalyzeStruct.payload, "\"status\":\"0\""))
					{
						GPIO_OUTPUT_SET(5, 0);
						SendRelayStateFlage = 1;
					}
				}
			}
		}
		else
		{
			MqttAnalyzeStruct.Len = 0;//需要在这里清零,让函数从数组的开始地址读取
			if(MQTTPacket_read(MqttAnalyzeStruct.buff,MQTTAnalyzeBuffLen, transport_getdata) == PINGRESP)//心跳包返回
			{
				KeepAliveSendFlage = 0;
				KeepAliveSendCount = 0;
			}
			else
			{
				MqttAnalyzeStruct.Len = 0;//需要在这里清零,让函数从数组的开始地址读取
				if(MQTTPacket_read(MqttAnalyzeStruct.buff,MQTTAnalyzeBuffLen, transport_getdata) == DISCONNECT)//断开连接
				{
					dbg_printf("\n The server actively disconnects \n");
					espconn_disconnect(&TcpClient);
					espconn_delete(&TcpClient);
					espconn_connect(&TcpClient);//重新连接服务器
					MqttState = 0;
				}
			}
		}

		memset(MqttAnalyzeStruct.buff,0,sizeof(MqttAnalyzeStruct.buff));
	}


	while(len--)
	{
		uart0_write_char(*(pdata++));//发送到串口
	}
}


//断开了连接
void TcpClientDisCon(void *arg)
{
	dbg_printf("\nTcpClientDisCon\n");
	espconn_connect(&TcpClient);//重新连接服务器
	MqttState = 0;
}

//连接上服务器
void TcpConnected(void *arg)
{
    dbg_printf("\nTcpConnected\n");
    espconn_regist_recvcb(&TcpClient, TcpClientRecv);//设置接收回调
    espconn_regist_disconcb(&TcpClient, TcpClientDisCon);//设置断开连接回调


	uint8_t mac[6];
	wifi_get_macaddr(STATION_IF, mac);
	sprintf(MQTTid, MACSTR, MAC2STR(mac));
	dbg_printf("\n MAC:%s\n",MQTTid);


	#ifdef UserCustomConfig //使用自定义
		MQTTStringSubTopic[0].cstring = MQTTPublishTopic;//设置订阅的主题
	#else
		memset(MQTTPublishTopic,0,sizeof(MQTTPublishTopic));
		sprintf(MQTTPublishTopic,"%s%s","device/",&MQTTid[0]);//组合发布的主题
	#endif

    MainLen = MqttConnectMqtt(MQTTid,MQTTUserName,MQTTPassWord,MQTTkeepAlive,MQTTWillFlage,MQTTid,MQTTWillMessage,MQTTWillQos,MQTTWillRetained);

	if(MainLen>0)espconn_send(&TcpClient,MqttSendData,MainLen);//发送数据
	else dbg_printf("\nConnect MQTT Data Err\n");

    MqttState = 1;
}

//连接出错
void TcpConnectErr(void *arg, sint8 err)
{
    dbg_printf("\nTcpConnectErr=%d\n",err);
    espconn_connect(&TcpClient);//链接
    MqttState = 0;
}

//所有需要定时操作的函数在此函数中执行
LOCAL void ICACHE_FLASH_ATTR
public_timer_callback(void)
{
	/****************************************配网-开始*********************************************/
	if(GPIO_INPUT_GET(0) == 0)//按键按下
	{
		public_timer_cnt++;
		if(public_timer_cnt>=300 && public_timer_state==0)//3S
		{
			dbg_printf("\nstartsmart\n");
			public_timer_state=1;
			wifi_station_disconnect();
			wifi_set_opmode(STATION_MODE);
			smartconfig_set_type(SC_TYPE_ESPTOUCH_AIRKISS);//SmartConfig  +  AirKiss
			xTaskCreate(smartconfig_task, "smartconfig_task", 256, NULL, 2, NULL);
		}
	}
	else
	{
		if(public_timer_state!=1 && public_timer_cnt>0 && public_timer_cnt<300)//短按复位
		{
			dbg_printf("\nsystem_restart\n");
			system_restart();//复位
		}
		public_timer_cnt=0;
	}

	switch(public_timer_state)
	{
		case 0:break;
		case 1:
			public_timer_out++;
			public_timer_cnt1++;
			if(public_timer_out>=6000)//60S
			{
				dbg_printf("\nsmartconfig_timeout\n");
				system_restart();//复位
			}
			if(public_timer_cnt1>10)//LED快闪
			{
				public_timer_cnt1=0;
				GPIO_OUTPUT_SET(2, 1-GPIO_INPUT_GET(2));//LED快闪
			}
			break;
		default:break;
	}
	/****************************************配网-结束*********************************************/


	/****************控制时间发送温湿度数据--开始******************/
	SendTHCnt++;
	if(SendTHCnt>500)
	{
		SendTHCnt=0;
		SendTHFlage=1;
	}
	/****************控制时间发送温湿度数据--结束******************/


	/****************************************MQTT-开始*********************************************/
	if(MqttState==3)
	{
		if(KeepAliveSendFlage) KeepAliveTimeOut++;
		else  KeepAliveTimeOut=0;
		KeepAliveTimeCnt++;


		if(SendRelayStateFlage)
		{
			SendRelayStateFlage=0;
			if(GPIO_INPUT_GET(5))
			{
				MainLen = sprintf(MainBuffer,"{\"data\":\"switch\",\"bit\":\"1\",\"status\":\"%s\"}","1");//发送的数据
			}
			else
			{
				MainLen = sprintf(MainBuffer,"{\"data\":\"switch\",\"bit\":\"1\",\"status\":\"%s\"}","0");//发送的数据
			}

			MqttPublishTopicStruct.retained = 1;//需要服务器保留消息
			MainLen = MqttPublish(MqttPublishTopicStruct,(unsigned char*)MainBuffer,MainLen);//打包MQTT数据
			if(MainLen>0)espconn_send(&TcpClient,MqttSendData,MainLen);//发送数据
			else dbg_printf("\nSend Data Err\n");
		}
		else if(SendTHFlage)
		{
			SendTHFlage =0 ;
			MainLen = sprintf(MainBuffer,"{\"data\":\"TH\",\"bit\":\"1\",\"temperature\":\"%d\",\"humidity\":\"%d\"}",DHT11Data[2],DHT11Data[0]);//
			MqttPublishTopicStruct.retained = 0;//不需要服务器保留消息
			MainLen = MqttPublish(MqttPublishTopicStruct,(unsigned char*)MainBuffer,MainLen);//打包MQTT数据
			if(MainLen>0)espconn_send(&TcpClient,MqttSendData,MainLen);//发送数据
			else dbg_printf("\nSend TH Data Err\n");
		}
		else if(SendKeepAliveFlage)
		{
			SendKeepAliveFlage=0;
			MainLen = KeepAliveFunction();//配置心跳数据  数据打包进 MqttSendData数组
			if(MainLen>0)espconn_send(&TcpClient,MqttSendData,MainLen);//发送数据
			else dbg_printf("\nSend Data Err\n");
		}




		if(KeepAliveTimeCnt/100 >= MQTTkeepAlive)//到时间发送心跳包
		{
			KeepAliveTimeCnt = 0;
			KeepAliveSendFlage = 1;//发送了心跳包,定时器启用 KeepAliveTimeOut++;
			KeepAliveSendCount++;  //发送心跳包次数加一

			SendKeepAliveFlage = 1;
		}
		else
		{
			if(KeepAliveTimeOut >3000)//心跳包超过时间没有返回应答
			{
				KeepAliveTimeOut = 0;
				SendKeepAliveFlage = 1;
				KeepAliveSendCount++;//发送心跳包次数加一
			}
		}

		if(KeepAliveSendCount>=3)//心跳包发送了两次都没有返回
		{
			KeepAliveSendCount=0;
			dbg_printf("\n KeepAlive Err \n");
			espconn_disconnect(&TcpClient);
			espconn_delete(&TcpClient);
			espconn_connect(&TcpClient);//重新连接服务器
			MqttState = 0;
		}
	}
	/****************************************MQTT-结束*********************************************/
}

/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void user_init(void)
{
	GPIO_OUTPUT_SET(5, 0);
	GPIO_OUTPUT_SET(2, 0);
	GPIO_OUTPUT_SET(0, 1);
	uart_init_new();
	printf("SDK version:%s\n", system_get_sdk_version());

	wifi_set_opmode(STATIONAP_MODE);//配置WiFi的模式STATION + AP AP--连接WIFI自身的无线实现通信  STATION--wifi连接路由器,手机或者电脑也连接路由器,实现通信
	soft_ap_Config.ssid_len = strlen(SSID);//热点名称长度，与你实际的名称长度一致就好
	memcpy(soft_ap_Config.ssid,SSID,soft_ap_Config.ssid_len);//实际热点名称设置，可以根据你的需要来
	memcpy(soft_ap_Config.password,PWD,strlen(PWD));//热点密码设置
	soft_ap_Config.authmode = AUTH_WPA2_PSK;//加密模式
	soft_ap_Config.channel = 1;//信道，共支持1~13个信道
	soft_ap_Config.max_connection = 4;//最大连接数量，最大支持四个，默认四个

	wifi_softap_set_config_current(&soft_ap_Config);//设置 Wi-Fi SoftAP 接口配置，不保存到 Flash
	//    wifi_softap_set_config(&soft_ap_Config);//设置 Wi-Fi SoftAP 接口配置，保存到 Flash
	UartCallbackRegister(UartReadCallback);//把 UartReadCallback 函数地址传过去,在串口里面调用


	os_timer_disarm(&public_timer);
	os_timer_setfn(&public_timer, (os_timer_func_t *)public_timer_callback, NULL);
	os_timer_arm(&public_timer, 10, 1);//10ms

	wifi_set_event_handler_cb(wifi_event_monitor_handle_event_cb);


	//初始化TCP
	espconn_init();
	TcpClient.type = ESPCONN_TCP;
	TcpClient.state = ESPCONN_NONE;
	TcpClient.proto.tcp = &esptcp;
	//服务器IP 地址
	TcpClient.proto.tcp->remote_ip[0]=IP[0];
	TcpClient.proto.tcp->remote_ip[1]=IP[1];
	TcpClient.proto.tcp->remote_ip[2]=IP[2];
	TcpClient.proto.tcp->remote_ip[3]=IP[3];

	TcpClient.proto.tcp->remote_port = Port;//连接端口号
	espconn_regist_connectcb(&TcpClient, TcpConnected);//注册连接函数
	espconn_regist_reconcb(&TcpClient, TcpConnectErr);//注册连接出错函数

	StartDHT11();

	i2c_master_gpio_init();

	OLEDStart();
}





