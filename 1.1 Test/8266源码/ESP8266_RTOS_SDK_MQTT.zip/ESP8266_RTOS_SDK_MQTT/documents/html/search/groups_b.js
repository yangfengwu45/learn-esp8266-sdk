var searchData=
[
  ['rate_20control_20apis',['Rate Control APIs',['../group__WiFi__Rate__Control__APIs.html',1,'']]]
];
