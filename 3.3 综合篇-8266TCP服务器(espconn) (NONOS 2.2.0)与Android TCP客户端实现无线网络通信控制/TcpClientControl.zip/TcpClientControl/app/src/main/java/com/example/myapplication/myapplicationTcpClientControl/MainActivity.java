package com.example.myapplication.myapplicationTcpClientControl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    EditText editTextIPAddress,editTextPort;//输入IP地址,端口号
    Button buttonConnect;//连接按钮
    Socket socket;
    InputStream inputStream;//输入流
    byte[] RevBuff = new byte[1460];//缓存数据
    OutputStream outputStream;//输出流
    MyHandler myHandler;//使用Handler更新控件
    ImageButton imageButtonControl;
    TextView textViewState;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myHandler = new MyHandler();
        buttonConnect = findViewById(R.id.buttonConnect);
        buttonConnect.setText("连接");
        editTextIPAddress = findViewById(R.id.editTextIPAddress);
        editTextPort = findViewById(R.id.editTextPort);
        textViewState = findViewById(R.id.textViewState);
        imageButtonControl = findViewById(R.id.imageButtonControl);
        imageButtonControl.setTag(false);//默认是关闭

        imageButtonControl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final byte[] bytes = new byte[4];
                bytes[0] = (byte) 0xaa;
                bytes[1] = (byte) 0x55;
                bytes[2] = (byte) 0x01;
                if ((boolean) (imageButtonControl.getTag()) == false) {
                    imageButtonControl.setImageResource(R.mipmap.switch_button_on);//吸合图片
                    imageButtonControl.setTag(true);
                    bytes[3] = 0x01;
                } else {
                    imageButtonControl.setImageResource(R.mipmap.switch_button_off);//断开图片
                    imageButtonControl.setTag(false);
                    bytes[3] = 0x00;
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try{
                            outputStream.write(bytes,0,4);//发送数据
                        }catch (Exception e){}
                    }
                }).start();
            }
        });

        buttonConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonConnect.getText()=="连接"){
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Message msg = myHandler.obtainMessage();//从消息队列拉取个消息变量
                            try{
                                socket = new Socket(editTextIPAddress.getText().toString(),Integer.valueOf(editTextPort.getText().toString()));
                                if(socket.isConnected()){
                                    msg.what = 1;//设置消息变量的 what 变量值 为1
                                    inputStream = socket.getInputStream();//获取数据流通道
                                    outputStream = socket.getOutputStream();//获取输出流
                                    Recv();//调用接收函数
                                }
                            }catch (Exception e){
                                msg.what = 0;//设置消息变量的 what 变量值 为0
                            }
                            myHandler.sendMessage(msg);//插入消息队列
                        }
                    }).start();
                }
                else{
                    try{ socket.close(); }catch (Exception e){} //关闭连接
                    try{ inputStream.close(); }catch (Exception e){}
                    buttonConnect.setText("连接");//按钮显示连接
                }
            }
        });
    }


    public void Recv(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (socket!= null && socket.isConnected()){
                    try{
                        int Len = inputStream.read(RevBuff);//获取数据
                        if(Len!=-1){
                            Message msg = myHandler.obtainMessage();//从消息队列拉取个消息变量
                            msg.what = 3;//设置消息变量的 what 变量值 为3
                            msg.arg1 = Len;//接收的数据个数
                            msg.obj = RevBuff;//传递数据
                            myHandler.sendMessage(msg);//插入消息队列
                        }
                        else{//连接异常断开
                            Message msg = myHandler.obtainMessage();//从消息队列拉取个消息变量
                            msg.what = 0;//设置消息变量的 what 变量值 为0
                            myHandler.sendMessage(msg);//插入消息队列
                            break;
                        }
                    }catch (Exception e){//连接异常断开
                        Message msg = myHandler.obtainMessage();//从消息队列拉取个消息变量
                        msg.what = 0;//设置消息变量的 what 变量值 为0
                        myHandler.sendMessage(msg);//插入消息队列
                        break;
                    }
                }
            }
        }).start();
    }

    //Handler
    class MyHandler extends Handler {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 0:
                    Toast.makeText(MainActivity.this,"连接出错",Toast.LENGTH_SHORT).show();
                    buttonConnect.setText("连接");//按钮显示连接
                    break;
                case 1:
                    buttonConnect.setText("断开");//按钮显示断开
                    break;
                case 3:
                    byte[] Buffer = new byte[msg.arg1];//创建一个数组
                    System.arraycopy((byte[])msg.obj, 0,Buffer , 0, msg.arg1);//拷贝数据
                    //提示byte范围是-127 -- 127   &0xFF以后便自动转为int型
                    if ( msg.arg1>=4 && Buffer[0] == 0x55 && (Buffer[1]&0xff) == 0xaa ) {
                        if (Buffer[2] == 0x01) {
                            if (Buffer[3] == 0x01)//继电器吸合
                            {
                                textViewState.setText("吸合");
                                imageButtonControl.setImageResource(R.mipmap.switch_button_on);//吸合图片
                                imageButtonControl.setTag(true);
                            }
                            else if (Buffer[3] == 0x00)//继电器断开
                            {
                                textViewState.setText("断开");
                                imageButtonControl.setImageResource(R.mipmap.switch_button_off);//断开图片
                                imageButtonControl.setTag(false);
                            }
                        }
                    }
                    break;
                default: break;
            }
        }
    }
}
